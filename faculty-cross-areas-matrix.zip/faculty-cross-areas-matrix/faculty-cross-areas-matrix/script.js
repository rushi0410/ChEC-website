 document.addEventListener('DOMContentLoaded', function () {
      const researchAreas = [ "Machine Learning", "Adsorption",
"Photocatalysis", "Process Systems Engineering",
"Colloid and interfacial Phenomena", "Battery",
"Granular Physics", "NanoBiotechnology",
"Renewable energy, and sustainability", "Artificial Intelligence",
"Surface engineering of polymer and metal surfaces", "Metal organic frameworks",
"Food Process Engineering", "Microfluidics and Corrosion Simulation",
"Energy and Environmental Sciences", "Soft matter and Food physics",
"Molecular simulation", "Biosensing",
"Data Science", "Process Control",
"Biomaterial", "Microfluidics",
"Process systems engineering", "Adsorption",];

      const facultyData = [
        { name: "Prof. Anki Reddy Katha", research: ["Energy and Environmental Sciences", "Granular Physics"] },
        { name: "Prof. Arun K. Tangirala", research: ["Process Systems Engineering"," Data Science","Artificial Intelligence"] },
        { name: "Prof. K S M S Raghavarao", research: ["Food Process Engineering"] },
        { name: "Prof. Sasidhar Gumma", research: ["Metal organic frameworks", "Adsorption"] },
        { name: "Prof. Thamida Sunil Kumar", research: ["Microfluidics and Corrosion Simulation"] },
        { name: "Dr. M Nabil", research: ["Process Control", "Machine Learning"] },
        { name: "Dr. Anil Vir", research: ["Microfluidics"] },
        { name: "Dr. Brindha Moorthy", research: ["Battery"] },
        { name: "Dr. Narendra Singh", research: ["Photocatalysis"," Surface engineering of polymer and metal surfaces"] },
        { name: "Dr. Trivikram Nallamilli", research: ["Colloid and interfacial Phenomena", "Soft matter and Food physics"] },
        { name: "Dr. Nilesh Choudhary", research: ["Molecular simulation"] },
        { name: "Dr. S Uday Kumar", research: ["NanoBiotechnology","Biomaterial"] },
        { name: "Dr. Ranjith Thangavel", research: ["Battery"] },
        { name: "Dr. Shamik Misra", research: ["Process systems engineering", "Renewable energy, and sustainability"] },
        { name: "Dr. Payel Sen", research: ["Biosensing"] },
        { name: "Dr. Bijoy Kumar Das", research: ["Battery"] },
      ];

      const researchContainer = document.getElementById('research-areas-container');
      const tableHeader = document.getElementById('table-header');
      const tableBody = document.getElementById('table-body');

      function renderResearchAreas() {
        researchContainer.innerHTML = ''; 
        researchAreas.forEach((area, index) => {
          const card = document.createElement('div');
          // Using standard CSS classes instead of Tailwind
          card.className = `research-card ${index === 0 ? 'active' : ''}`;
          card.textContent = area;
          card.dataset.area = area;
          researchContainer.appendChild(card);
        });
      }

      function renderTable() {
        tableHeader.innerHTML = '';
        const headerRow = document.createElement('tr');
        let headerHTML = `<th scope="col" class="sticky-col sticky-header">Professor Name</th>`;
        researchAreas.forEach(area => {
          headerHTML += `<th scope="col" class="sticky-header">${area}</th>`;
        });
        headerRow.innerHTML = headerHTML;
        tableHeader.appendChild(headerRow);

        tableBody.innerHTML = '';
        facultyData.forEach(faculty => {
          const row = document.createElement('tr');
          row.className = 'table-row';

          let rowHTML = `<td class="sticky-col faculty-name-cell">${faculty.name}</td>`;

          researchAreas.forEach(area => {
            const hasResearch = faculty.research.includes(area);
            rowHTML += `
              <td class="status-cell">
                ${hasResearch ?
                `<div class="icon-check" title="${faculty.name} works in ${area}">
                  <svg xmlns="http://www.w3.org/2000/svg" class="svg-icon" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="3">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M5 13l4 4L19 7" />
                  </svg>
                </div>`
                :
                `<div class="icon-empty" title="No specialization in ${area}"></div>`
                }
              </td>`;
          });
          row.innerHTML = rowHTML;
          tableBody.appendChild(row);
        });
      }

      researchContainer.addEventListener('click', function (e) {
        if (e.target.dataset.area) {
          document.querySelectorAll('.research-card').forEach(card => card.classList.remove('active'));
          e.target.classList.add('active');

          const areaIndex = researchAreas.indexOf(e.target.dataset.area);
          document.querySelectorAll('th, td').forEach(cell => cell.classList.remove('highlight-col'));

          if (areaIndex !== -1) {
            const colIndex = areaIndex + 2; // +2 to account for the first name column and 1-based nth-child
            document.querySelectorAll(`tr > *:nth-child(${colIndex})`).forEach(cell => {
              if (!cell.classList.contains('sticky-header')) {
                cell.classList.add('highlight-col');
              }
            });
          }
        }
      });

      renderResearchAreas();
      renderTable();
    });